package com.mindhub.homebanking.Models;

public enum TransactionType {
    DEBIT,
    CREDIT
}
