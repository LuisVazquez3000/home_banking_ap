package com.mindhub.homebanking.Models;

public enum CardColor {
GOLD,
SILVER,
TITANIUM
}
