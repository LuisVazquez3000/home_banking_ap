package com.mindhub.homebanking.Models;

public enum CardType {
    CREDIT,
    DEBIT
}
